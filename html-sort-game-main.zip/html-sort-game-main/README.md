# html-sort-game
Gamified javascript/html webapp to allow manually performing bubblesort.

Press the "Next" button or the "N" key on your keyboard to move the cursor (highlighting selected items) to the right. Press the "Swap" button or the "S" key on your keyboard to swap the two items under the cursor. This will also move the cursor one space to the right.  
When you reach the end of a pass press "OK" or the "Space" key on your keyboard if you believe the list is sorted, otherwise press "Cancel" or the "Escape" key on your keyboard to perform another pass.

If you manually change the number of elements you will need to restart to generate a new list of that size.